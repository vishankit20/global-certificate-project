package in.backend;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/marksentry")
public class MarksEntry extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String name = (String) session.getAttribute("name");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Enter Marks for " + name + "</h1>");
        out.println("<form action='result' method='post'>");
        for (int i = 1; i <= 6; i++) {
            out.println("Subject " + i + ": <input type='number' name='subject" + i + "' required><br>");
        }
        out.println("<button type='submit'>Generate Result</button>");
        out.println("</form>");
        out.println("</body></html>");
    }
}
