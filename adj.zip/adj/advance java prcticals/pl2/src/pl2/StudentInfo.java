/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pl2;

/**
 *
 * @author ankitvishwakarma
 */
import java.sql.*;
import java.util.Scanner;

public class StudentInfo {
    static final String URL = "jdbc:mysql://localhost:3306/StudentDB";
    static final String USER = "root";
    static final String PASSWORD = "rootroot";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n Student Information System");
            System.out.println("1. Insert Student Record");
            System.out.println("2. Update Student Record");
            System.out.println("3. Delete Student Record");
            System.out.println("4. Display All Students");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    insertStudent();
                    break;
                case 2:
                    updateStudent();
                    break;
                case 3:
                    deleteStudent();
                    break;
                case 4:
                    displayStudents();
                    break;
                case 5:
                    System.out.println("Exiting Program...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    public static void insertStudent() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Student Age: ");
            int age = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter Course Name: ");
            String course = scanner.nextLine();

            String sql = "INSERT INTO Students (name, age, course) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, course);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println(" Student record inserted successfully!");
            }

        } catch (SQLException e) {
            System.out.println(" Error inserting student!");
            e.printStackTrace();
        }
    }

    public static void updateStudent() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter New Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Age: ");
            int age = scanner.nextInt();
            scanner.nextLine();
            System.out.print("Enter New Course: ");
            String course = scanner.nextLine();

            String sql = "UPDATE Students SET name=?, age=?, course=? WHERE student_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, course);
            pstmt.setInt(4, id);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println(" Student record updated successfully!");
            } else {
                System.out.println(" Student ID not found!");
            }

        } catch (SQLException e) {
            System.out.println(" Error updating student!");
            e.printStackTrace();
        }
    }

    public static void deleteStudent() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter Student ID to delete: ");
            int id = scanner.nextInt();

            String sql = "DELETE FROM Students WHERE student_id=?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println(" Student record deleted successfully!");
            } else {
                System.out.println(" Student ID not found!");
            }

        } catch (SQLException e) {
            System.out.println(" Error deleting student!");
            e.printStackTrace();
        }
    }

    public static void displayStudents() {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Students")) {

            System.out.println("\n Student Records ");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("student_id") +
                        ", Name: " + rs.getString("name") +
                        ", Age: " + rs.getInt("age") +
                        ", Course: " + rs.getString("course"));
            }

        } catch (SQLException e) {
            System.out.println(" Error displaying students!");
            e.printStackTrace();
        }
    }
}