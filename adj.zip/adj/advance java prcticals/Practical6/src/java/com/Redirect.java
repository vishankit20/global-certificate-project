package com;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/Redirect")
public class Redirect extends HttpServlet{
    protected void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException{
        String url = request.getParameter("url");
        if(!url.startsWith("http://")&&!url.startsWith("https://")){
            url = "http://" + url;
        }
        response.sendRedirect(url);
    }
}