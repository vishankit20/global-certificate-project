/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UserLogin;

import java.sql.*;
import java.util.Scanner;

public class UserLogin {
    public static void main(String[] args) {
       
        String url = "jdbc:mysql://localhost:3306/UserDB"; 
        String user = "root"; 
        String password = "rootroot"; 
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Username: ");
        String inputUsername = scanner.nextLine();

        System.out.print("Enter Password: ");
        String inputPassword = scanner.nextLine();

        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");

            
            Connection conn = DriverManager.getConnection(url, user, password);

           
            String sql = "SELECT * FROM Users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, inputUsername);
            stmt.setString(2, inputPassword);

            
            ResultSet rs = stmt.executeQuery();

           
            if (rs.next()) {
                System.out.println("Successful Login!");
            } else {
                System.out.println("Invalid Username or Password");
            }

            
            rs.close();
            stmt.close();
            conn.close();
            scanner.close();

        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver Not Found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database Error!");
            e.printStackTrace();
        }
    }
}